const express = require('express');
const app = express();
const scanRoute = require('./routes/scanRoute');

app.use(express.json());
app.use('/scan', scanRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
