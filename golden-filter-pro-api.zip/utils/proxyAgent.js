const HttpsProxyAgent = require('https-proxy-agent');

const proxyAgent = new HttpsProxyAgent({
  host: process.env.PROXY_HOST,
  port: process.env.PROXY_PORT,
  auth: `${process.env.PROXY_USER}:${process.env.PROXY_PASS}`
});

module.exports = proxyAgent;
