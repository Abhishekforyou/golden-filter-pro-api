const axios = require('axios');
const proxyAgent = require('../utils/proxyAgent');

async function fetchNSEData(symbol) {
  try {
    const response = await axios.get(`https://www.nseindia.com/api/quote-equity?symbol=${symbol}`, {
      httpsAgent: proxyAgent,
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'application/json'
      }
    });
    return response.data;
  } catch (error) {
    console.error('NSE Fetch Error:', error.message);
    return null;
  }
}

module.exports = fetchNSEData;
