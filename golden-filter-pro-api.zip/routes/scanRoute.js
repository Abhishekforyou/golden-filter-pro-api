const express = require('express');
const router = express.Router();
const fetchNSEData = require('../services/nseFetcher');

router.get('/', async (req, res) => {
  const symbol = req.query.symbol || 'RELIANCE';
  const data = await fetchNSEData(symbol);
  if (data) {
    res.json({ success: true, data });
  } else {
    res.status(500).json({ success: false, message: 'Failed to fetch data' });
  }
});

module.exports = router;
